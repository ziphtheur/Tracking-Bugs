import {React, useState, useEffect} from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';
import Header from '../Header/Header';
import Sidebar from '../Sidebar/Sidebar';


const CreateProject = () => {
    const history = useHistory();
    const [projectName, setProjectName] = useState('');
    const [projectLead, setProjectLead] = useState('');
    const [userList, setUserList] = useState([]);
    const [selectedUserList, setSelectedUserList] = useState([]);
    const [selectedUserName, setSelectedUserName] = useState('');

    useEffect(() => {
        axios.get("http://localhost:5000/projectusers")
        .then(res => {
           setUserList(res.data)
           console.log(res.data)
        })
    }, [])

    const buttonClickRight = () => {
        let newArr;
            newArr = userList.filter(obj => {
                if(obj.user === selectedUserName){
                    setSelectedUserList([{ user: selectedUserName, role: obj.role }, ...selectedUserList])
                }                
                return obj.user !== selectedUserName
            })
            setUserList(newArr);
        
    }

    const buttonClickLeft = () => {
        let newArr;
        newArr = selectedUserList.filter(obj => {
            if(obj.user === selectedUserName){
                    setUserList([{ user: selectedUserName, role: obj.role }, ...userList])
            }                
            return obj.user !== selectedUserName
        })
        setSelectedUserList(newArr);
    }

    const buttonClickSelector = (e) => {
        setSelectedUserName(e.target.value);
    }

    const createProject = (e) => {
        let users = selectedUserList.map(obj => {
            if(obj.user === projectLead){
                return { 
                    user: obj.user,
                    role: obj.role,
                    project: projectName,
                    projectlead: true
                }
            }else{
                return {
                    user: obj.user,
                    role:obj.role,
                    project: projectName,
                    projectlead: false
                }
            }
        })

        axios.post("http://localhost:5000/createproject", {
        users
        }).then(res =>{
            console.log(res.data)
            history.push('/manage-projects')
        })

    }

    return (
        <>
            <div className="create-project-container">
                
                <label>Project Name</label>
                <input type="text" value={projectName} onChange={(e) => setProjectName(e.target.value)} />
                <label>Project Lead</label>
                <select value={projectLead} onChange={(e) => setProjectLead(e.target.value) }>
                    <RenderLeaderList arr={selectedUserList} num={100} />
                </select>

                <label>Project Members</label>
                <ul className="create-project-all-members">
                    <RenderNamesList arr={userList} func={(event) => buttonClickSelector(event)} num={0} />
                </ul>
                <button onClick={() => buttonClickLeft()}>{'<<<'}</button>
                <button onClick={() => buttonClickRight()}>{'>>>'}</button>
                <ul className="create-project-selected-members">
                    <RenderNamesList arr={selectedUserList} func={(event) => buttonClickSelector(event)} num={userList.length - 1} />
                </ul>
                
                <button onClick={() => createProject()}>Create Project</button>
            </div>
            <Header />
            <Sidebar />
        </>
    )
}

const RenderNamesList = ({arr = [], func, num}) => {

    return(
        <>
            {arr.map((obj, index) =>{
                return(
                <li key={index + num}>
                    <button value={obj.user} onClick={func}>{obj.user}</button>
                </li>
                )
            })}
        </>
    )  
}

const RenderLeaderList = ({arr = [], num}) => {
     return(
         <>
            {arr.map((obj, index) => {
                return(
                    <option value={obj.user} key={index + num} >{obj.user}</option>
                )
            })}
         </>
     )
}

export default CreateProject;