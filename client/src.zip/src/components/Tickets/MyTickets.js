import {React, useState, useEffect} from 'react';
import axios from 'axios';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import Header from '../Header/Header';
import Sidebar from '../Sidebar/Sidebar';

const MyTickets = ({ loginReducer }) => {
    const history = useHistory();
    const [ticketList, setTicketList] = useState([]);

    useEffect(() => {
        let name = loginReducer;
        

        axios.post('http://localhost:5000/get-projects', name)
        .then(res => {
            let tickets = [];
            console.log(res.data, '1st');

             res.data.forEach(obj =>{
                axios.post('http://localhost:5000/get-tickets', obj)
                .then(res => {
                    console.log(res.data, '2nd');

                    res.data.forEach(obj => {
                        tickets.push(obj);
                    })
                })
            })
            
            setTicketList(tickets)
        })
        

    }, [loginReducer])

    return (
        <> 
        <Header />
        <Sidebar />
       <div className='my-tickets-container'>
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Project</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Description</th>
                        <th>Time Created</th>
                        <th>Submitter</th>
                    </tr>
                </thead>
                <tbody>
                    <RenderTicketTable tempArr={ticketList} />
                </tbody>                
            </table>
            <button onClick={() => console.log(ticketList) }>ticketslist</button>
       </div>
        </>
    )
}


const RenderTicketTable = ({tempArr = []}) => {
    console.log(tempArr, 'Render ticket table')

    return(
        <>
            {tempArr.map((obj, index) =>{

                return(
                    <tr key={index}>
                        <td>{obj.title}</td>
                        <td>{obj.project}</td>
                        <td>{obj.priority}</td>
                        <td>{obj.ticketStatus}</td>
                        <td>{obj.description}</td>
                        <td>{obj.createdTime}</td>
                        <td>{obj.submitter}</td>
                    </tr>
                )
            })}
            
        </>
    )
}

const mapStateToProps = (state) => {
    return {
        loginReducer: state.login
    }
}

export default connect(mapStateToProps)(MyTickets);