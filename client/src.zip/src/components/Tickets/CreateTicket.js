import {React, useState, useEffect} from 'react';
import axios from 'axios';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import Header from '../Header/Header';
import Sidebar from '../Sidebar/Sidebar';
import './CreateTicket.css';

const CreateTicket = ({ loginReducer }) => {
    const history = useHistory();
    const [ticketTitle, setTicketTitle] = useState("");
    const [ticketDescription, setTicketDescription] = useState("");
    const [projectName, setProjectName] = useState("");
    const [assignedDeveloper, setAssignedDeveloper] = useState("Any");
    const [ticketPriority, setTicketPriority] = useState("High");
    const [ticketStatus, setTicketStatus] = useState("On Hold");
    const [currrentTime, setCurrentTime] = useState("");
    const [submitter, setSubmitter] = useState("");
    const [projectList, setProjectList] = useState([]);   

    useEffect( () => {
        const dateTime = new Date();
        const tempDateTime = setInterval(() => {
            if(dateTime.getSeconds() < 10){
                setCurrentTime(`${dateTime.getFullYear()}-${dateTime.getMonth()+1}-${dateTime.getDate()} ${dateTime.getHours()}:${dateTime.getMinutes()}:0${dateTime.getSeconds()}`)    
            }else{
                setCurrentTime(`${dateTime.getFullYear()}-${dateTime.getMonth()+1}-${dateTime.getDate()} ${dateTime.getHours()}:${dateTime.getMinutes()}:${dateTime.getSeconds()}`)
            }

            
        }, 1000)

        return () => { clearInterval(tempDateTime)}


        
    }, [currrentTime])

    useEffect( () => {
        setSubmitter(loginReducer.loginStatus) 

        axios.get("http://localhost:5000/projectname")
        .then(res => {
            setProjectList(res.data)
        }) 

    }, [loginReducer])  

    const formSubmit = (event) => {
        event.preventDefault();
        let ticket = {
            ticketTitle: ticketTitle,
            projectName: projectName,
            assignedDeveloper: assignedDeveloper,
            ticketDescription: ticketDescription,
            ticketPriority: ticketPriority,
            ticketStatus: ticketStatus,
            currrentTime: currrentTime,
            submitter: submitter
        }


        console.log(ticketTitle, projectName, assignedDeveloper, ticketDescription, ticketPriority, ticketStatus, currrentTime, submitter)

        axios.post('http://localhost:5000/createticket', ticket)
        .then(res => {
            console.log(res.data)
        })

        history.push('/dashboard')
    }    

// Assigned developer needs to be admin accesss only
    return (
        <>
            <Sidebar />
            <Header />
            <div className="create-ticket-container">
                <form className="create-ticket" onSubmit={(e) => formSubmit(e)}>
                    <div className="create-ticket-form-div">
                        <label >Ticket Title</label>
                        <input id="ticket-Title" type="text" value={ticketTitle} onChange={event => setTicketTitle(event.target.value)}/>
                    </div>
                   <div className="create-ticket-form-div">
                        <label>Project Name</label>
                        <select value={projectName} placeholder='Select a Project' onChange={e => setProjectName(e.target.value)}>
                            <option value='select' disabled>Select a Project</option>
                            <RenderProjectList tempArr={projectList} num={10} />
                        </select>
                   </div>
                    <div className="create-ticket-form-div">
                        <label>Assigned Developer</label>
                        <select value={assignedDeveloper} onChange={e => setAssignedDeveloper(e.target.value)}>
                            <option value="Any">Any</option>
                            <option value={null}> employees assigned </option>
                        </select>
                    </div>
                    <div className="create-ticket-form-div">
                        <label>Ticket Priority</label>
                        <select value={ticketPriority} onChange={e => setTicketPriority(e.target.value)}>
                            <option className="priority-high" value="High">High</option>
                            <option className="priority-medium" value="Medium">Medium</option>
                            <option className="priority-low" value="Low">Low</option>
                        </select>
                    </div>
                    <div className="create-ticket-form-div">
                        <label>Ticket Status</label>
                        <select value={ticketStatus} onChange={e => setTicketStatus(e.target.value)}>
                            <option value="On Hold">On Hold</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Fixed">Fixed</option>
                            <option value="Under Review">Under Review</option>
                            <option value="Approved">Approved</option>
                            <option value="Deployed">Deployed</option>
                            <option value="Closed">Closed</option>        
                        </select>
                    </div>
                        <label>Description</label>
                        <textarea wrap="true" required rows="8" value={ticketDescription} onChange={event => setTicketDescription(event.target.value)} />
                    <input type="submit" value="Submit Ticket" />
                </form>
            </div>
        </>
    )
}

const mapStateToProps = (state) => {
    return {
        loginReducer: state.login
    }
}

const RenderProjectList = ({ tempArr = [], num }) => {

    return (
        <>
            {tempArr.map((obj, index) => {
                return(
                <option value={obj} key={index + num}>{obj}</option>
                ) 
            })}
        </>
    )
}

export default connect(mapStateToProps)(CreateTicket);