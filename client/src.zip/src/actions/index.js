export const finalLogin = (login) => {
    return {
        type: 'SET_LOGIN',
        payload: login
    }
}

export const editingProject = (project) => {
    return {
        type: 'SET_PROJECT',
        payload: project
    }
}